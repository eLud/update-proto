#!/bin/sh

#  UnzipAndUnquarantine.sh
#  BeamUpdaterProto
#
#  Created by Ludovic Ollagnier on 04/05/2021.
#  

#unzip "./Updates/NativeConnect-1.1-(11a8d62).zip" -d "./Updates/"
#xattr -d -r com.apple.quarantine "./Updates/NativeConnect.app"

echo $0
echo $1
#unzip $0 -d $1
#xattr -d -r com.apple.quarantine "./Updates/NativeConnect.app"
